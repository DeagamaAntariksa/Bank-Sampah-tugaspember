package com.example.core.domain.model

data class Session(
    val id: String,
    val username: String,
    val role: String
)